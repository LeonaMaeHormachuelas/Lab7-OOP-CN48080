import javax.swing.*;

public class CustomFrame extends JFrame {

    private int posX;
    private int posY;

    public CustomFrame(String title, int x, int y) {
        super(title);
        this.posX = x;
        this.posY = y;
        initUI();
    }

    private void initUI() {
        // Width and height stay fixed at 350x200; X and Y now come from the caller
        setBounds(posX, posY, 350, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
}
