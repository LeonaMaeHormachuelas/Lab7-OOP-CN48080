public class TestCustomFrameArgs {

    // Default coordinates used if no command-line arguments are supplied
    private static int x = 200;
    private static int y = 200;

    private static void parseArgs(String[] args) {
        if (args.length >= 2) {
            x = Integer.parseInt(args[0]);
            y = Integer.parseInt(args[1]);
        }
    }

    public static void main(String[] args) {
        // Run as: java TestCustomFrameArgs 100 150
        parseArgs(args);
        CustomFrame frame = new CustomFrame("Custom Subclassed Frame", x, y);
        frame.setVisible(true);
    }
}
