import javax.swing.*;

public class CloseOperationTest {

    private static JFrame frameA;
    private static JFrame frameB;

    // Frame A: clicking the "X" does nothing - the window stays open
    // because no action has been told to run on close.
    private static void createFrameA() {
        frameA = new JFrame("Frame A - DO_NOTHING_ON_CLOSE");
        frameA.setSize(300, 150);
        frameA.setLocation(100, 100);
        frameA.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
    }

    // Frame B: clicking the "X" disposes the window and, since this is the
    // only close operation of this kind in the app, terminates the JVM.
    private static void createFrameB() {
        frameB = new JFrame("Frame B - EXIT_ON_CLOSE");
        frameB.setSize(300, 150);
        frameB.setLocation(450, 100);
        frameB.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        createFrameA();
        createFrameB();
        frameA.setVisible(true);
        frameB.setVisible(true);
    }
}

/*
 Observed behavior when clicking the "X" button:

 Frame A (DO_NOTHING_ON_CLOSE):
   The window does not close and the program keeps running. Frame B
   remains open as well, since nothing told the JVM to react to the click.

 Frame B (EXIT_ON_CLOSE):
   The window closes and System.exit() is invoked internally, which shuts
   down the entire application - including Frame A, even though Frame A's
   own close operation was set to do nothing.
*/
