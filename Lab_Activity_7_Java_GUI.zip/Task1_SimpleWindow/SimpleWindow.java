import javax.swing.*;

public class SimpleWindow {

    private static JFrame mainFrame;

    // Step 3: Instantiate the JFrame with its title
    public static void createFrame() {
        mainFrame = new JFrame("Laboratory Activity - Simple Window");
    }

    // Steps 4-6: Configure size, close operation, and resizability
    public static void configureFrame() {
        mainFrame.setSize(400, 250);
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setResizable(false);
    }

    // Step 7: Display the window
    public static void showFrame() {
        mainFrame.setVisible(true);
    }

    public static void main(String[] args) {
        createFrame();
        configureFrame();
        showFrame();
    }
}
