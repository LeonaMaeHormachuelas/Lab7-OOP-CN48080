import javax.swing.*;

public class CustomFrame extends JFrame {

    public CustomFrame(String title) {
        super(title);
        initUI();
    }

    private void initUI() {
        // Position at (200, 200) from screen top-left, width: 350, height: 200
        setBounds(200, 200, 350, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
}
