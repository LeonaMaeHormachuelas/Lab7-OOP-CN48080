public class TestCustomFrame {

    public static void main(String[] args) {
        CustomFrame frame = new CustomFrame("Custom Subclassed Frame");
        frame.setVisible(true);
    }
}
