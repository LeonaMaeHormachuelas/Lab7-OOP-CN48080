import javax.swing.*;

public class ProfilePanelDemo extends JFrame {

    private JPanel containerPanel;
    private JLabel loginLabel;
    private JButton submitButton;
    private JButton cancelButton;

    public ProfilePanelDemo() {
        super("User Registration Panel");
        configureWindow();
        buildComponents();
        assembleContainer();
        setContentPane(containerPanel);
    }

    // Step 3: title (via super), close operation, and dimensions
    private void configureWindow() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 200);
    }

    // Step 4-5: create the panel and the three Swing components
    private void buildComponents() {
        containerPanel = new JPanel();
        loginLabel = new JLabel("System User Login");
        submitButton = new JButton("Submit");
        cancelButton = new JButton("Cancel");
    }

    // Step 5: add components to containerPanel
    private void assembleContainer() {
        containerPanel.add(loginLabel);
        containerPanel.add(submitButton);
        containerPanel.add(cancelButton);
    }

    public static void main(String[] args) {
        ProfilePanelDemo demo = new ProfilePanelDemo();
        demo.setVisible(true);
    }
}
